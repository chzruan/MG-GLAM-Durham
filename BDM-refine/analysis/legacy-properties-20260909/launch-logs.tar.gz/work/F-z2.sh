#!/bin/bash
#SBATCH --job-name=bdmprop-F-z2
#SBATCH --account=dp004
#SBATCH --partition=cosma8-serial
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=00:15:00
#SBATCH --output=/cosma8/data/dp203/dc-ruan1/mgglam_claude/MG-GLAM/BDM-refine/analysis/legacy-properties-20260909/work/F-z2-%j.log
set -euo pipefail
export LINES=40 COLUMNS=120
module purge
module load intel_comp/2024.2.0
module load compiler-rt tbb compiler
export OMP_NUM_THREADS="$SLURM_CPUS_PER_TASK"
export OMP_DYNAMIC=FALSE OMP_PROC_BIND=close OMP_PLACES=cores
export OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1
ulimit -c 0
cd /cosma8/data/dp203/dc-ruan1/mgglam_claude/MG-GLAM
scontrol show job "$SLURM_JOB_ID"
test "$(sha256sum BDM-refine/analysis/legacy-properties-20260909/measure.py | cut -d " " -f 1)" = aa2ff98c44ba4a4793eea65bd472d284ad84f45422d4128db967164599b01ccc
test "$(sha256sum BDM-refine/analysis/legacy-properties-20260909/checks.py | cut -d " " -f 1)" = c0a0aeb22074b8b0d021c017b9127671e2ad64beb2aac4615b1eddac5ab3f461
test "$(sha256sum PMP2linker.f90 | cut -d " " -f 1)" = 39f7e514d1db9fb3b9c7545fc7f3269b4e20b5ee2d1366945f8916b997e4cd5d
test "$(sha256sum PMP2mod_density.f90 | cut -d " " -f 1)" = 199ad91667f32c068bab5882c08046c24970ca3caa0321d277cfc7d704e88ed3
micromamba run -n cosemu python3 -B /cosma8/data/dp203/dc-ruan1/mgglam_claude/MG-GLAM/BDM-refine/analysis/legacy-properties-20260909/measure.py --redshift 2 --threads 2
